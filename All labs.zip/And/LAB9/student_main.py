import re

# Завдання 1
def task1(str):
    pat = r'^(?=.*[a-z])(?=.*\d)[a-z0-9]+$'
    result = bool(re.fullmatch(pat, str))
    print("Task 1:", result)
    return result

# Завдання 2
def task2(stri):
    patt = r'.*[A-Z].*'
    result = bool(re.match(patt,stri))
    print("Task 2:", result)
    return result

# Завдання 3
def task3(strin):
    patte = r'^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
    result = bool(re.match(patte,strin))
    print("Task 3:", result)
    return result

# Завдання 4
def task4(string):
    patter = r'^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$'
    result = bool(re.match(patter,string))
    print("Task 4:", result)
    return result

# Завдання 5
def task5(st):
    pattern = r'^\d{5}(-\d{4})?$'
    result = bool(re.match(pattern,st))
    print("Task 5:", result)
    return result

# Завдання 6
def task6(s):
    pa = r'^[a-z0-9_-]{6,12}$'
    result = bool(re.match(pa,s))
    print("Task 6:", result)
    return result

# Завдання 7
def task7(lala):
    p = r'^[4-6]\d{3}-?\d{4}-?\d{4}-?\d{4}$'
    result = bool(re.match(p,lala))
    print("Task 7:", result)
    return result

# Завдання 8
def task8(lolo):
    lol = r'^\d{3}-\d{2}-\d{4}$'
    result = bool(re.match(lol,lolo))
    print("Task 8:", result)
    return result

# Завдання 9
def task9(lele):
    lel = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@#$%])[A-Za-z\d@#$%]{8,}$'
    result = bool(re.match(lel,lele))
    print("Task 9:", result)
    return result

# Завдання 10
def task10(lyly):
    lyl = r'^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$'
    result = bool(re.match(lyl,lyly))
    print("Task 10:", result)
    return result

# Примеры использования функций
task1("hello123")
task2("AbCdEfG")
task3("192.168.1.1")
task4("12:34:56")
task5("12345")
task6("username")
task7("4567-1234-5678-1234")
task8("123-45-6789")
task9("Password@1")
task10("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
