# Лабораторна робота №17: Генератори та структури даних
# Мета роботи:
Метою даної лабораторної роботи є ознайомлення з генераторами в Python, їх використанням для обробки даних та створення ефективних ітераторів для різних структур даних.

# Опис завдання:
У цій лабораторній роботі необхідно реалізувати різні генератори, які можуть використовуватися для роботи з числовими послідовностями, структурами даних (словниками, списками, графами), обробки файлів та ін. Ці генератори мають забезпечувати ефективне створення та обробку даних у Python.

# Виконання роботи:
Для виконання роботи було створено окремий репозиторій на GitHub. Генератори реалізовано у файлі `main.py`.

# Структура проекту

- `lab17/`
  - `student_main.py` - основний код програми
  - `README.md` - опис проекту

# Опис файлів

- `student_main.py`: містить функції-генератори, які реалізують різні ітерації та обробку даних.
- `README.md`: містить опис мети роботи, завдань, кроків виконання, результатів, висновків та інструкцій щодо запуску.

# Опис генераторів

1. Генератор чисел з наданого списку:
    ```python
    def number_generator(numbers):
        for number in numbers:
            yield number
    ```

2. Генератор парних чисел у заданому діапазоні:
    ```python
    def even_number_generator(start, end):
        for number in range(start, end + 1):
            if number % 2 == 0:
                yield number
    ```

3. Генератор непарних чисел у заданому діапазоні:
    ```python
    def odd_number_generator(start, end):
        for number in range(start, end + 1):
            if number % 2 != 0:
                yield number
    ```

4. Генератор чисел Фібоначчі:
    ```python
    def fibonacci_generator():
        a, b = 0, 1
        while True:
            yield a
            a, b = b, a + b
    ```

5. Генератор простих чисел до заданого обмеження:
    ```python
    def prime_number_generator(limit):
        def is_prime(n):
            if n < 2:
                return False
            for i in range(2, int(n**0.5) + 1):
                if n % i == 0:
                    return False
            return True

        for number in range(2, limit + 1):
            if is_prime(number):
                yield number
    ```

6. Генератор для обходу дерева в префіксному порядку:
    ```python
    def pre_order_traversal(root):
        if root:
            yield root.value
            yield from pre_order_traversal(root.left)
            yield from pre_order_traversal(root.right)
    ```

7. Генератор для обходу дерева в інфіксному порядку:
    ```python
    def in_order_traversal(root):
        if root:
            yield from in_order_traversal(root.left)
            yield root.value
            yield from in_order_traversal(root.right)
    ```

8. Генератор для обходу дерева в постфіксному порядку:
    ```python
    def post_order_traversal(root):
        if root:
            yield from post_order_traversal(root.left)
            yield from post_order_traversal(root.right)
            yield root.value
    ```

9. Генератор для обходу графа в глибину (DFS):
    ```python
    def dfs_traversal(graph, start):
        stack = [start]
        visited = set()
        while stack:
            vertex = stack.pop()
            if vertex not in visited:
                yield vertex
                visited.add(vertex)
                stack.extend(reversed(graph[vertex]))
    ```

10. Генератор для обходу графа в ширину (BFS):
    ```python
    def bfs_traversal(graph, start):
        from collections import deque
        queue = deque([start])
        visited = set()
        while queue:
            vertex = queue.popleft()
            if vertex not in visited:
                yield vertex
                visited.add(vertex)
                queue.extend(graph[vertex])
    ```

11. Генератори для роботи зі словниками:
    ```python
    def dict_keys_generator(dictionary):
        for key in dictionary:
            yield key

    def dict_values_generator(dictionary):
        for value in dictionary.values():
            yield value

    def dict_items_generator(dictionary):
        for item in dictionary.items():
            yield item
    ```

12. Генератори для роботи з файлами:
    ```python
    def file_lines_generator(file_path):
        with open(file_path, 'r') as file:
            for line in file:
                yield line.strip()

    def file_words_generator(file_path):
        with open(file_path, 'r') as file:
            for line in file:
                for word in line.split():
                    yield word
    ```

13. Генератор для ітерації по символах рядка:
    ```python
    def string_chars_generator(string):
        for char in string:
            yield char
    ```

14. Генератор унікальних елементів:
    ```python
    def unique_elements_generator(elements):
        seen = set()
        for element in elements:
            if element not in seen:
                yield element
                seen.add(element
    ```

15. Генератор для реверсу списку:
    ```python
    def reverse_list_generator(elements):
        for element in reversed(elements):
            yield element
    ```

16. Генератори для обчислень:
    ```python
    def cartesian_product_generator(list1, list2):
        for product in itertools.product(list1, list2):
            yield product

    def permutations_generator(elements):
        for permutation in itertools.permutations(elements):
            yield permutation

    def combinations_generator(elements):
        for length in range(1, len(elements) + 1):
            for combination in itertools.combinations(elements, length):
                yield combination

    def powers_of_two_generator(n):
        for i in range(n + 1):
            yield 2 ** i

    def powers_of_base_generator(base, limit):
        power = 1
        while power <= limit:
            yield power
            power *= base

    def squares_generator(start, end):
        for number in range(start, end + 1):
            yield number ** 2

    def cubes_generator(start, end):
        for number in range(start, end + 1):
            yield number ** 3

    def factorials_generator(n):
        for i in range(n + 1):
            yield math.factorial(i)

    def collatz_sequence_generator(n):
        while n != 1:
            yield n
            if n % 2 == 0:
                n = n // 2
            else:
                n = 3 * n + 1
        yield 1

    def geometric_progression_generator(a, r, limit):
        term = a
        while term <= limit:
            yield term
            term *= r

    def arithmetic_progression_generator(a, d, limit):
        term = a
        while term <= limit:
            yield term
            term += d

    def running_sum_generator(numbers):
        total = 0
        for number in numbers:
            total += number
            yield total

    def running_product_generator(numbers):
        total = 1
        for number in numbers:
            total *= number
            yield total
    ```

### Приклади використання

```python
# Генератор чисел з наданого списку
gen = number_generator([1, 2, 3, 4, 5])
print(list(gen))  # [1, 2, 3, 4, 5]

# Генератор парних чисел у заданому діапазоні
gen = even_number_generator(1, 10)
print(list(gen))  # [2, 4, 6, 8, 10]

# Генератор чисел Фібоначчі
gen = fibonacci_generator()
print([next(gen) for _ in range(10)])  # [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]

# Генератор простих чисел до 20
gen = prime_number_generator(20)
print(list(gen))  # [2, 3, 5, 7, 11, 13, 17, 19]

# Генератор для обходу графа в глибину (DFS)
graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F'],
    'D': [],
    'E': ['F'],
    'F': []
}
gen = dfs_traversal(graph, 'A')
print(list(gen))  # ['A', 'C', 'F', 'B', 'E', 'D']

# Генератор для реверсу списку
gen

 = reverse_list_generator([1, 2, 3, 4, 5])
print(list(gen))  # [5, 4, 3, 2, 1]

# Генератор факторіалів до 5
gen = factorials_generator(5)
print(list(gen))  # [1, 1, 2, 6, 24, 120]
```

# Висновок:
У цій лабораторній роботі було реалізовано різноманітні генератори для обробки даних та ітерацій у Python. Генератори дозволяють створювати ефективні ітератори, які економлять пам'ять та полегшують обробку великих обсягів даних.

# Інструкції з запуску
# Команда для запуску
Запустіть програму, виконавши команду:
python student_main.py

# Коментарі у коді
Коментарі у коді використовуються для пояснення логіки реалізації кожної функції та алгоритму.

# Коміти в репозиторії
Всі коміти мають інформативні повідомлення, які описують внесені зміни.