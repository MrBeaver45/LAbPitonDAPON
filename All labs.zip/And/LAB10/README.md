# Лабораторна робота №10: Об'єктно-орієнтоване програмування в Python

# Мета роботи:
Метою даної лабораторної роботи є ознайомлення з основами об'єктно-орієнтованого програмування (ООП) у мові Python, а також з ключовими концепціями ООП: інкапсуляція, наслідування та поліморфізм.

# Опис завдання:
У даній лабораторній роботі необхідно реалізувати кілька класів, які демонструють використання основних принципів ООП в Python:

1. Створити клас `Student` з атрибутами `name`, `age` та `grade`.
2. Додати до класу `Student` метод `dis`, який повертає рядок з інформацією про студента.
3. Створити клас `Animal` з атрибутами `name` та `sound`, та клас-нащадок `Dog`, який додатково має атрибут `breed`.
4. Реалізувати поліморфізм за допомогою класів `Bird`, `Sparrow` та `Penguin`.
5. Продемонструвати інкапсуляцію на прикладі класу `Encapsulation`.
6. Створити клас `Rectangle` з методом для обчислення периметра.
7. Реалізувати клас `AverageCalculator` для обчислення середнього значення з набору чисел.

# Виконання роботи:
Для виконання роботи було створено окремий репозиторій на GitHub. Кожна задача реалізована у вигляді окремого класу у файлі `main.py`.

# Структура проекту

- `lab10/`
  - `student_main.py` - основний код програми
  - `README.md` - опис проекту

# Опис файлів

- `student_main.py`: містить класи для кожного завдання, які демонструють різні аспекти ООП.
- `README.md`: містить опис мети роботи, завдань, кроків виконання, результатів, висновків та інструкцій щодо запуску.

# Опис основних класів та методів

1. Клас `Student`:
    ```python
    class Student:
        def __init__(self, name, age, grade):
            self.name = name
            self.age = age
            self.grade = grade
        def dis(self):
            return f"Name: {self.name}, Age: {self.age}, Mark: {self.grade}"
    ```

2. Клас `Animal` та його нащадок `Dog`:
    ```python
    class Animal:
        def __init__(self, name, sound):
            self.name = name
            self.sound = sound
        def make_sound(self):
            return f"{self.name}: {self.sound}"
    
    class Dog(Animal):
        def __init__(self, name, sound, breed):
            super().__init__(name, sound)
            self.breed = breed
    ```

3. Класи `Bird`, `Sparrow` та `Penguin`:
    ```python
    class Bird:
        def fly(self):
            return None
    class Sparrow(Bird):
        def fly(self):
            return "Sparrow flies high"
    class Penguin(Bird):
        def fly(self):
            return "Penguin cannot fly"
    ```

4. Клас `Encapsulation`:
    ```python
    class Encapsulation:
        def __init__(self, public, private, protected):
            self.public = public
            self.__private = private
            self._protected = protected
    ```

5. Клас `Rectangle`:
    ```python
    class Rectangle:
        def __init__(self, width, height):
            self.width = width
            self.height = height
        def calculate_perimeter(self):
            return 2 * (self.width + self.height)
    ```

6. Клас `AverageCalculator`:
    ```python
    class AverageCalculator:
        def __init__(self, numbers):
            self.numbers = numbers
        def calculate_average(self):
            if not self.numbers:
                return 0
            return sum(self.numbers) / len(self.numbers)
    ```

# Приклади використання

```python
# Приклад використання класу Student
student = Student("Ivan", 30, 2)
print(student.dis())  # Name: Ivan, Age: 30, Mark: 2

# Приклад використання класів Animal та Dog
animal = Animal("Lala", "Auuuuuuu")
dog = Dog("Lala", "Auuuuuuu", "Golden Retriever")
print(animal.make_sound())  # Output: Lala: Auuuuuuu
print(dog.make_sound())     # Output: Lala: Auuuuuuu

# Приклад використання класів Bird, Sparrow та Penguin
bird = Bird()
sparrow = Sparrow()
penguin = Penguin()
print(bird.fly())       # Output: None
print(sparrow.fly())    # Output: Sparrow flies high
print(penguin.fly())    # Output: Penguin cannot fly

# Приклад використання класу Encapsulation
obj = Encapsulation(1, 2, 3)
print(obj.public)                     # Output: 1
print(obj._Encapsulation__private)    # Output: 2
print(obj._protected)                 # Output: 3

# Приклад використання класу Rectangle
rectangle = Rectangle(4, 5)
print(rectangle.calculate_perimeter())  # Output: 18

# Приклад використання класу AverageCalculator
numbers = [5, 10, 15, 20]
avg_calculator = AverageCalculator(numbers)
print(avg_calculator.calculate_average())  # Expected output: 12.5
```

# Результати:
Отримані результати показують, що всі класи правильно реалізують відповідні концепції ООП.

# Скріншоти або приклади виводу програми

1. `student.dis()` повертає `Name: Ivan, Age: 30, Mark: 2`.
2. `animal.make_sound()` повертає `Lala: Auuuuuuu`.
3. `dog.make_sound()` повертає `Lala: Auuuuuuu`.
4. `sparrow.fly()` повертає `Sparrow flies high`.
5. `penguin.fly()` повертає `Penguin cannot fly`.
6. `obj.public` повертає `1`, `obj._Encapsulation__private` повертає `2`, `obj._protected` повертає `3`.
7. `rectangle.calculate_perimeter()` повертає `18`.
8. `avg_calculator.calculate_average()` повертає `12.5`.

# Висновок:
Мета роботи була досягнута. Було створено класи, які демонструють використання основних принципів ООП в Python. Проблеми, які виникли під час роботи, були пов'язані з правильним використанням механізмів наслідування та інкапсуляції, і вони були вирішені шляхом вивчення документації та тестування.

# Інструкції з запуску:
# Команда для запуску:

python student_main.py

# Коментарі у коді
Коментарі у коді використовуються для пояснення логіки реалізації кожного класу та методу.

# Коміти в репозиторі
Всі коміти мають інформативні повідомлення, які описують внесені зміни.