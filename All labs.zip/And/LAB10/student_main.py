#1
class Student:
    def __init__(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade

#2
class Student:
    def __init__(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade
    def dis(self):
        return f"Name: {self.name}, Age: {self.age}, Mark: {self.grade}"

#print(student.dis())  # Name: Ivan, Age: 30, Mark: 2


#3
class Animal:
    def __init__(self, name, sound):
        self.name = name
        self.sound = sound
    def make_sound(self):
        return f"{self.name}: {self.sound}"


class Dog(Animal):
    def __init__(self, name, sound, breed):
        super().__init__(name, sound)
        self.sound = breed

#print(animal.make())  # Output: Lala:
#print(dog.make())  # Output: Lala: Auuuuuuu

#4
class Bird:
    def fly(self):
        return None
class Sparrow(Bird):
    def fly(self):
        return "Sparrow flies high"
class Penguin(Bird):
    def fly(self):
        return "Penguin cannot fly"

#print(bird.fly())     # Output: None
#print(sparrow.fly())  # Output: Sparrow flies high
#print(penguin.fly())  # Output: Penguin cannot fly

#5
class Encapsulation:
    def __init__(self, public, private, protected):
        self.public = public
        self.private = private
        self.__protected = protected
#obj = Encapsulation(1, 2, 3)
#print(obj.public)                            # Output: 1
#print(obj.private)                          # Output: 2
#print(obj._Encapsulation__protected)         # Output: 3
#print(obj.__protected)                       # AttributeError
#6
class Rectangle:
    def __init__(self,width,height ):
        self.width = width
        self.height = height
    def calculate_perimeter(self):
        return 2 * (self.width + self.height)

#print(rectangle.calculatorpy())  # Output: 18
#7
class AverageCalculator:
    def __init__(self, numbers):
        self.numbers = numbers
    def calculate_average(self):
        if not self.numbers:
            return 0
        return sum(self.numbers) / len(self.numbers)
# Example of class usage:
#numbers = [5, 10, 15, 20]
#avg_calculator = AvgCal(numbers)
#print(avg_calculator.calavg()) # Expected output: 12.5