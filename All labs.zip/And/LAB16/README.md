# Лабораторна робота №16: Advanced TODO List
# Мета роботи:
Метою цієї лабораторної роботи є розробка розширеного TODO списку з можливістю додавання, редагування, видалення та перегляду завдань з різними атрибутами та функціональними можливостями, такими як пріоритет, нагадування, повторення, та ведення історії змін.

# Опис завдання:
Необхідно реалізувати клас `Task` для представлення окремого завдання та клас `Schedule` для управління списком завдань. `Task` має містити атрибути для заголовка, опису, дати виконання, статусу, пріоритету, приміток, тривалості, повторення та дати нагадування. `Schedule` має надавати методи для додавання, видалення, оновлення завдань, сортування, фільтрації, збереження та завантаження завдань з файлу.

# Виконання роботи:
# Структура проекту

- `lab16/`
  - `student_main.py` - основний код програми
  - `README.md` - опис проекту

# Опис файлів

- `student_main.py`: містить класи `Task` та `Schedule`, які реалізують функціональність розширеного TODO списку.
- `README.md`: містить опис мети роботи, завдань, кроків виконання, результатів, висновків та інструкцій щодо запуску.

# Опис класів
# Клас `Task`

1. Конструктор класу:
    ```python
    class Task:
        def __init__(self, title, description, due_date, status="Pending", priority="Medium", notes="", duration=0, recurrence=None, reminder_date=None):
            self.title = title
            self.description = description
            self.due_date = due_date
            self.status = status
            self.priority = priority
            self.notes = notes
            self.duration = duration
            self.recurrence = recurrence
            self.reminder_date = reminder_date
    ```

2. Метод для перевірки завдання на сьогодні:
    ```python
    def is_due_today(self):
        return self.due_date == date.today()
    ```

3. Метод для конвертації завдання у словник:
    ```python
    def to_dict(self):
        return {
            'title': self.title,
            'description': self.description,
            'due_date': self.due_date.isoformat(),
            'status': self.status,
            'priority': self.priority,
            'notes': self.notes,
            'duration': self.duration,
            'recurrence': self.recurrence,
            'reminder_date': self.reminder_date.isoformat() if self.reminder_date else None
        }
    ```

4. Метод для створення завдання зі словника:
    ```python
    @staticmethod
    def from_dict(data):
        return Task(
            title=data['title'],
            description=data['description'],
            due_date=date.fromisoformat(data['due_date']),
            status=data.get('status', 'Pending'),
            priority=data.get('priority', 'Medium'),
            notes=data.get('notes', ''),
            duration=data.get('duration', 0),
            recurrence=data.get('recurrence'),
            reminder_date=date.fromisoformat(data['reminder_date']) if data.get('reminder_date') else None
        )
    ```

# Клас `Schedule`

1. Конструктор класу:
    ```python
    class Schedule:
        def __init__(self):
            self.tasks = []
            self.history = []
    ```

2. Метод для додавання завдання:
    ```python
    def add_task(self, task):
        self.tasks.append(task)
        self.history.append(('added', task))
    ```

3. Метод для видалення завдання:
    ```python
    def remove_task(self, task_title):
        task = self.get_task(task_title)
        if task:
            self.tasks.remove(task)
            self.history.append(('removed', task))
    ```

4. Метод для отримання завдання за заголовком:
    ```python
    def get_task(self, task_title):
        for task in self.tasks:
            if task.title == task_title:
                return task
        return None
    ```

5. Метод для сортування завдань за датою виконання:
    ```python
    def sort_tasks_by_due_date(self):
        return sorted(self.tasks, key=lambda task: task.due_date)
    ```

6. Метод для оновлення завдання:
    ```python
    def update_task(self, task_title, **kwargs):
        task = self.get_task(task_title)
        if task:
            for key, value in kwargs.items():
                if hasattr(task, key):
                    setattr(task, key, value)
            self.history.append(('updated', task))
    ```

7. Метод для позначення завдання як виконаного:
    ```python
    def mark_as_completed(self, task_title):
        task = self.get_task(task_title)
        if task:
            task.status = "Completed"
            self.history.append(('completed', task))
    ```

8. Метод для знаходження завдань за ключовим словом:
    ```python
    def find_task_by_keyword(self, keyword):
        return [task for task in self.tasks if keyword in task.title or keyword in task.description]
    ```

9. Метод для перевірки дедлайнів:
    ```python
    def check_deadlines(self):
        tomorrow = date.today() + timedelta(days=1)
        return [task for task in self.tasks if task.due_date == tomorrow]
    ```

10. Метод для збереження завдань у файл:
    ```python
    def save_to_file(self, filename):
        try:
            with open(filename, 'w') as file:
                tasks_data = [task.to_dict() for task in self.tasks]
                json.dump(tasks_data, file)
        except IOError as e:
            print(f"An error occurred while saving to file: {e}")
    ```

11. Метод для завантаження завдань з файлу:
    ```python
    def load_from_file(self, filename):
        try:
            with open(filename, 'r') as file:
                tasks_data = json.load(file)
                self.tasks = [Task.from_dict(data) for data in tasks_data]
                self.history.append(('loaded', filename))
        except (IOError, json.JSONDecodeError) as e:
            print(f"An error occurred while loading from file: {e}")
    ```

# Приклади використання

```python
from datetime import date, timedelta
from task_schedule import Task, Schedule

# Створення завдань
task1 = Task(title="Buy groceries", description="Milk, Bread, Eggs", due_date=date.today() - timedelta(days=1))
task2 = Task(title="Submit assignment", description="Math assignment", due_date=date.today() + timedelta(days=2))

# Створення розкладу
schedule = Schedule()
schedule.add_task(task1)
schedule.add_task(task2)

# Оновлення завдання
schedule.update_task("Buy groceries", description="Milk, Bread, Eggs, Cheese", due_date=date(2024, 5, 26))

# Позначення завдання як виконаного
schedule.mark_as_completed("Buy groceries")

# Збереження у файл
schedule.save_to_file("schedule.txt")

# Завантаження з файлу
schedule.load_from_file("schedule.txt")

# Виведення списку всіх завдань
print(schedule.list_all_tasks())
```

# Результати:
Отримані результати показують, що клас `Schedule` успішно реалізує функціональність розширеного TODO списку, забезпечуючи додавання, редагування, видалення завдань, фільтрацію, сортування, пошук, збереження та завантаження з файлу.

# Скріншоти або приклади виводу програми

1. Список завдань після додавання:
    ```python
    [Task(title='Buy groceries', description='Milk, Bread, Eggs', due_date=..., status='Pending', ...), Task(title='Submit assignment', description='Math assignment', due_date=..., status='Pending', ...)]
    ```

2. Завдання після оновлення:
    ```python
    Task(title='Buy groceries', description='Milk, Bread, Eggs, Cheese', due_date=datetime.date(2024, 5, 26), status='Pending', ...)
    ```

3. Завдання після позначення як виконаного:
    ```python
    Task(title='Buy groceries', description='Milk, Bread, Eggs, Cheese', due_date=datetime.date(2024, 5, 26), status='Completed', ...)
    ```

4. Список завдань після завантаження з файлу:
    ```python
    [Task(title='Buy groceries', description='Milk, Bread, Eggs, Cheese', due_date=datetime.date(2024, 5, 26), status='Completed', ...), Task(title='Submit assignment', description='Math assignment', due_date=..., status='Pending', ...)]
    ```

# Висновок:
Мета роботи була досягнута. Було реалізовано класи `Task` та `Schedule`, які дозволяють ефективно керувати списком завдань. Робота з завданнями різної складності, підтримка повторення, нагадування та збереження даних у файл є важливими навичками для розробки подібних систем у реальних умовах.

# Інструкції з запуску
# Команда для запуску
Запустіть програму, виконавши команду:
python student_main.py

# Коментарі у коді
Коментарі у коді використовуються для пояснення логіки реалізації кожної функції та алгоритму.

# Коміти в репозиторії
Всі коміти мають інформативні повідомлення, які описують внесені зміни.