# Лабораторна робота №11: Розширена робота з масивами чисел у Python
# Мета роботи:
Метою даної лабораторної роботи є поглиблення знань з роботи з масивами чисел у Python, а також освоєння різних методів обробки масивів, включаючи сортування, пошук, обчислення сум, перетворення та аналіз даних.

# Опис завдання:
У цій лабораторній роботі необхідно реалізувати функції, що виконують різні операції з масивами чисел, зокрема:

1. Обчислення суми квадратів чисел у масиві.
2. Знаходження суми всіх елементів, що більше або дорівнюють середньому значенню масиву.
3. Сортування масиву за кількістю повторень елементів.
4. Знаходження пропущеного числа в послідовності.
5. Пошук найдовшої підпослідовності послідовних чисел.
6. Переміщення елементів масиву на задану кількість позицій.
7. Обчислення масиву добутків всіх елементів масиву, крім поточного.
8. Знаходження максимальної суми підмасиву.
9. Виведення елементів матриці по спіралі.
10. Знаходження найближчих точок до початку координат.

# Виконання роботи:
Для виконання роботи було створено окремий репозиторій на GitHub. Кожна задача реалізована у вигляді окремої функції у файлі `main.py`.

# Структура проекту

- `lab11/`
  - `student_main.py` - основний код програми
  - `README.md` - опис проекту

# Опис файлів

- `student_main.py`: містить функції для кожного завдання, які виконують різні операції з масивами чисел.
- `README.md`: містить опис мети роботи, завдань, кроків виконання, результатів, висновків та інструкцій щодо запуску.

# Опис основних функцій

1. Функція `task1(a)`:
    ```python
    from collections import Counter

    def task1(a):
        return sum(x ** 2 for x in a)
    ```

2. Функція `task2(ar)`:
    ```python
    def task2(ar):
        avg = sum(ar) / len(ar)
        return sum(x for x in ar if x >= avg)
    ```

3. Функція `task3(arr)`:
    ```python
    def task3(arr):
        counts = Counter(arr)
        sorteda = sorted(arr, key=lambda x: (-counts[x], x))
        return sorteda
    ```

4. Функція `task4(arrr)`:
    ```python
    def task4(arrr):
        n = len(arrr) + 1
        totals = n * (n + 1) // 2
        sumarr = sum(arrr)
        return totals - sumarr
    ```

5. Функція `task5(number)`:
    ```python
    def task5(number):
        nums = set(number)
        ls = 0
        for num in nums:
            if num - 1 not in nums:
                curent = num
                current = 1
                while curent + 1 in nums:
                    curent += 1
                    current += 1
                ls = max(ls, current)
        return ls
    ```

6. Функція `task6(arrrr, s)`:
    ```python
    def task6(arrrr, s):
        s %= len(arrrr)
        arrrr[:] = arrrr[-s:] + arrrr[:-s]
        return arrrr
    ```

7. Функція `task7(numbs)`:
    ```python
    def task7(numbs):
        x = len(numbs)
        leftp = [1] * x
        rightp = [1] * x
        result = [1] * x
        for i in range(1, x):
            leftp[i] = leftp[i - 1] * numbs[i - 1]
        for i in range(x - 2, -1, -1):
            rightp[i] = rightp[i + 1] * numbs[i + 1]
        for i in range(x):
            result[i] = leftp[i] * rightp[i]
        return result
    ```

8. Функція `task8(numbes)`:
    ```python
    def task8(numbes):
        maxsu = float('-inf')
        currents = 0
        for num in numbes:
            currents = max(num, currents + num)
            maxsu = max(maxsu, currents)
        return maxsu
    ```

9. Функція `task9(matrix)`:
    ```python
    def task9(matrix):
        if not matrix:
            return []
        result = []
        top, bottom, left, right = 0, len(matrix) - 1, 0, len(matrix[0]) - 1
        while top <= bottom and left <= right:
            # Right
            for col in range(left, right + 1):
                result.append(matrix[top][col])
            top += 1
            # Down
            for row in range(top, bottom + 1):
                result.append(matrix[row][right])
            right -= 1
            # Left
            if top <= bottom:
                for col in range(right, left - 1, -1):
                    result.append(matrix[bottom][col])
                bottom -= 1
            # Up
            if left <= right:
                for row in range(bottom, top - 1, -1):
                    result.append(matrix[row][left])
                left += 1
        return result
    ```

10. Функція `task10(point, n)`:
    ```python
    def task10(point, n):
        # Calculate the distance of each point from the origin
        dis = [(x ** 2 + y ** 2, (x, y)) for x, y in point]
    
        # Sort the points based on their distance from the origin
        dis.sort()
    
        # Return the k closest points
        return [point for _, point in dis[:n]]
    ```

# Приклади використання

```python
print(task10([(1, 2), (1, 1), (3, 4)], 2))  # Output: [(1, 1), (1, 2)]
print(task9([[1, 2, 3], [4, 5, 6], [7, 8, 9]]))  # Output: [1, 2, 3, 6, 9, 8, 7, 4, 5]
print(task8([-2, 1, -3, 4, -1, 2, 1, -5, 4]))  # Output: 6
print(task7([1, 2, 3, 4]))  # Output: [24, 12, 8, 6]
print(task6([1, 2, 3, 4, 5], 2))  # Output: [4, 5, 1, 2, 3]
print(task5([100, 4, 200, 1, 3, 2]))  # Output: 4
print(task4([1, 2, 4, 5]))  # Output: 3
print(task3([4, 6, 2, 6, 4, 4, 6]))  # Output: [4, 4, 4, 6, 6, 6, 2]
print(task2([1, 2, 3, 4, 10]))  # Output: 14
print(task1([1, 2, 3]))  # Output: 14
```

# Результати
Отримані результати показують, що всі функції правильно виконують свої завдання, забезпечуючи обробку масивів чисел відповідно до вимог.

# Скріншоти або приклади виводу програми

1. `task10([(1, 2), (1, 1), (3, 4)], 2)` повертає `[(1, 1), (1, 2)]`.
2. `task9([[1, 2, 3], [4, 5, 6], [7, 8, 9]])` повертає `[1, 2, 3, 6, 9, 8, 7, 4, 5]`.
3. `task8([-2, 1, -3, 4, -1, 2, 1, -5, 4])` повертає `6`.
4. `task7([1, 2, 3, 4])` повертає `[24, 12, 8, 6]`.
5. `task6([1, 2, 3, 4, 5], 2)` повертає `[4, 5, 1, 2, 3]`.
6. `task5([100, 4, 200, 1, 3, 2])` повертає `4`.
7. `task4([1, 2, 4, 5])` повертає `3`.
8. `task3([4, 6, 2, 6, 4, 4, 6])` повертає `[4, 4, 4, 6, 6, 6, 2]`.
9. `task2([1, 2, 3, 4, 10])` повертає `14`.
10. `task1([1, 2, 3])` повертає `14`.

# Висновок:
Мета роботи була досягнута. Було реалізовано функції, що виконують різні операції з масивами чисел, що дозволило закріпити знання з обробки масивів у Python. Проблеми, які виникли під час роботи, були вирішені шляхом вивчення документації та тестування.

# Інструкції з запуску
# Команда для запуску
Запустіть програму, виконавши команду:
python student_main.py

# Коментарі у коді
Коментарі у коді використовуються для пояснення логіки реалізації кожної функції та алгоритму.

# Коміти в репозиторії
Всі коміти мають інформативні повідомлення, які описують внесені зміни.
